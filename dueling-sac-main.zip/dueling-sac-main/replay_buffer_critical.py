import numpy as np
import random

import torch


class ReplayBuffer(object):

    def __init__(self, size):
        """Create Replay buffer.

        Parameters
        ----------
        size: int
            Max number of transitions to store in the buffer. When the buffer
            overflows the old memories are dropped.
        """
        self._storage = []
        self._maxsize = size
        self._next_idx = 0

    def __len__(self):
        return len(self._storage)

    def add(self, obs_t, action, reward, obs_tp1, done):
        data = (obs_t, action, reward, obs_tp1, done)

        if self._next_idx >= len(self._storage):
            self._storage.append(data)
        else:
            self._storage[self._next_idx] = data
        self._next_idx = (self._next_idx + 1) % self._maxsize

    @torch.no_grad()
    def _encode_sample(self, idxes):
        obses_t, actions, rewards, obses_tp1, dones = [], [], [], [], []
        y = [obses_t, actions, rewards, obses_tp1, dones]
        for i in idxes:
            data = self._storage[i]
            for j in range(5):
                y[j].append(data[j])

        keys = ('obs', 'act', 'rew', 'obs2', 'done')
        dtypes = (np.float32, np.int64, np.float32, np.float32, np.float32)
        return {
            key: torch.as_tensor(np.asarray(_, dtype=dtype),
                                 device=torch.device('cuda'))
            for (key, dtype, _) in zip(keys, dtypes, y)
        }

    def sample(self, batch_size, recent=False):
        x = 0
        if recent:
            x = max(len(self._storage) - int(1e4), 0)
        idxes = [
            random.randint(x,
                           len(self._storage) - 1) for _ in range(batch_size)
        ]
        return self._encode_sample(idxes)
