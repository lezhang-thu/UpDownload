__all__ = ['MLPActorCritic']

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


class MLPActor(nn.Module):

    def __init__(self, num_actions):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(3136, 512), nn.ReLU(),
                                 nn.Linear(512, num_actions))

    def forward(self, obs):
        logit = self.net(obs)
        return logit.argmax(1), logit


class MLPActorCritic(nn.Module):

    def __init__(
        self,
        act_dim,
    ):
        super().__init__()

        self.conv = ConvOnly(4)
        # build policy and value functions
        self.pi = MLPActor(act_dim)
        self.q1 = nn.Sequential(nn.Linear(3136, 512), nn.ReLU(),
                                nn.Linear(512, act_dim))
        self.q2 = nn.Sequential(nn.Linear(3136, 512), nn.ReLU(),
                                nn.Linear(512, act_dim))

    @torch.no_grad()
    def act(self, obs):
        a, _ = self.pi(self.conv(obs))
        return a.item()


class ConvOnly(nn.Module):

    def __init__(self, frame_stack):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(frame_stack, 32, kernel_size=8, stride=4, padding=0),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=0),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),
            nn.ReLU(),
            nn.Flatten(),
        )

    def forward(self, obs):
        obs = obs.to(torch.float32) / 255.0
        # (B, C, H, W)
        obs = obs.permute(0, 3, 1, 2)
        return self.cnn(obs)
