import os
import sys

num_threads = "4"
os.environ["OMP_NUM_THREADS"] = num_threads  # export OMP_NUM_THREADS=4
os.environ[
    "OPENBLAS_NUM_THREADS"] = num_threads  # export OPENBLAS_NUM_THREADS=4
os.environ["MKL_NUM_THREADS"] = num_threads  # export MKL_NUM_THREADS=6
os.environ[
    "VECLIB_MAXIMUM_THREADS"] = num_threads  # export VECLIB_MAXIMUM_THREADS=4
os.environ["NUMEXPR_NUM_THREADS"] = num_threads  # export NUMEXPR_NUM_THREADS=6
import time
import random
import logging
import shutil
from copy import deepcopy
import itertools
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from ijcai_core import MLPActorCritic
#from spinup.utils.logx import EpochLogger

from zeta_atari_env import make_env
from replay_buffer_ijcai import ReplayBuffer

#def weights_init(m):
#    init_bias = 0.0
#    gain = nn.init.calculate_gain('relu')
#    if isinstance(m, nn.Conv2d):
#        nn.init.xavier_uniform_(m.weight, gain=gain)
#        nn.init.constant_(m.bias, init_bias)
#    elif isinstance(m, nn.Linear):
#        nn.init.xavier_uniform_(m.weight, gain=gain)
#        nn.init.constant_(m.bias, init_bias)


def setup_logging(save_dir, logger_name):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)

    ch = logging.StreamHandler(stream=sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter("[%(levelname)s: %(asctime)s] %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    #if not os.path.exists(save_dir):
    #    os.makedirs(save_dir)

    #fh = logging.FileHandler(os.path.join(save_dir, '{}'.format(logger_name)))
    #fh.setLevel(logging.INFO)
    #fh.setFormatter(formatter)
    #logger.addHandler(fh)
    return logger


def sac(
    env_fn,
    val_env_fn,
    actor_critic=MLPActorCritic,
    ac_kwargs=dict(),
    seed=0,
    steps_per_epoch=int(1e4),
    epochs=100,
    replay_size=int(0.5e6),
    #replay_size=int(1e6),
    #replay_size=int(1e5),
    gamma=0.99,
    polyak=0.995,
    #polyak=0.5,
    lr=1e-4,
    #lr=1e-3,
    batch_size=100,
    start_steps=10000,
    update_after=1000,
    #update_after=1600,
    update_every=50,
    num_val_episodes=10,
    logger_args=None,
    logger_kwargs=dict()):

    #x_logger = EpochLogger(**logger_kwargs)
    #x_logger.save_config(locals())

    env = env_fn()
    val_env = val_env_fn()
    obs_dim = env.observation_space.shape
    act_dim = env.action_space.n
    print('act_dim: {}'.format(act_dim))

    # Create actor-critic module and target networks
    alpha = 1e-2
    ac_kwargs['alpha'] = alpha
    ac = actor_critic(376, act_dim, **ac_kwargs).cuda()
    #ac.apply(weights_init)
    ac_targ = deepcopy(ac)
    del ac_targ.conv
    # Freeze target networks with respect to optimizers (only update via polyak averaging)
    for x in ac_targ.parameters():
        x.requires_grad = False

    # Experience buffer
    replay_buffer = ReplayBuffer(replay_size)
    output_threshold = 1e-4

    def compute_loss(data):
        o, a, r, o2, d = data['obs'], data['act'], data['rew'], data[
            'obs2'], data['done']
        #r = torch.clip(r.cuda(), -1, 1)
        r = r.cuda()
        d = d.cuda()
        o = ac.conv(o.cuda())
        a = a.cuda()
        logit_a = ac.pi(o)[1]

        adv4a_pi, v_loss = ac.Adv_values(o, None, logit_a)
        prob = F.softmax(logit_a, -1)

        a_entropy = torch.distributions.categorical.Categorical(
            logits=logit_a).entropy().mean()
        with torch.no_grad():
            if random.uniform(0, 1) < output_threshold:
                print('*' * 23)
                #        print('softmax[:2]:\n{}'.format(prob[:2]))
                print('a_entropy:', a_entropy)
        loss_pi = -alpha * a_entropy - (adv4a_pi.detach() * prob).sum(-1).mean()

        q = ac.Q_values(o, a, True, logit_a)
        # Bellman backup for Q functions
        with torch.no_grad():
            # Target actions come from *current* policy
            o2 = ac.conv(o2.cuda())
            a2, logit_a2, _ = ac.pi(o2)
            targ_q_values = ac_targ.Q_values(o2, None, True, ac_targ.pi(o2)[1])
            a2 = a2.unsqueeze(-1)
            backup = r + gamma * (
                1 - d) * (-alpha * F.log_softmax(logit_a2, -1).gather(-1, a2) +
                          targ_q_values.gather(-1, a2)).squeeze(-1)

        return loss_pi + F.huber_loss(q, backup) + v_loss

    full_opt = torch.optim.Adam(ac.parameters(), lr)

    def update():
        data = replay_buffer.sample(batch_size)
        full_opt.zero_grad()
        loss = compute_loss(data)
        loss.backward()
        #torch.nn.utils.clip_grad_norm_(ac.parameters(), 0.5)
        full_opt.step()

        for _ in range(1):
            o = ac.conv(replay_buffer.sample(batch_size)['obs'].cuda())
            with torch.no_grad():
                logit_a = ac.pi(o)[1]
            _, v_loss = ac.Adv_values(o, None, logit_a)
            full_opt.zero_grad()
            v_loss.backward()
            full_opt.step()

        # debug
        del data
        del loss

        # Finally, update target networks by polyak averaging.
        with torch.no_grad():
            for x, x_targ in zip([ac.v1, ac.adv1, ac.pi],
                                 [ac_targ.v1, ac_targ.adv1, ac_targ.pi]):
                for p, p_targ in zip(x.parameters(), x_targ.parameters()):
                    # NB: We use an in-place operations "mul_", "add_" to update target
                    # params, as opposed to "mul" and "add", which would make new tensors.
                    p_targ.data.mul_(polyak)
                    p_targ.data.add_((1 - polyak) * p.data)

    @torch.no_grad()
    def get_action(o, deterministic=False):
        o = torch.from_numpy(np.asarray(o)).unsqueeze(0).cuda()
        return ac.act(torch.as_tensor(o, dtype=torch.float32), deterministic)

    def val_agent(m):
        ep_ret, ep_len = 0, 0
        for j in range(m):
            o, d = val_env.reset(), False
            while not d:
                # Take deterministic actions at test time
                o, r, d, _ = val_env.step(get_action(o, True)[0])
                ep_ret += r
                ep_len += 1
        return ep_ret / m, ep_len / m

    logger = setup_logging('output', '{}.txt'.format(logger_args))
    # Prepare for interaction with environment
    total_steps = steps_per_epoch * epochs
    start_time = time.time()
    o, ep_ret, ep_len = env.reset(), 0, 0
    ep_ret_best = -1e5
    done_flag = False
    # Main loop: collect experience in env and update/log each epoch
    for t in range(1, total_steps + 1):
        if t > start_steps:
            a, _ = get_action(o)
        else:
            a = env.action_space.sample()

        # Step the env
        o2, r, d, _ = env.step(a)

        ep_ret += r
        ep_len += 1

        # Store experience to replay buffer
        replay_buffer.add(o, a, np.clip(np.asarray(r), -1, 1), o2, float(d))

        # Super critical, easy to overlook step: make sure to update
        # most recent observation!
        o = o2

        # End of trajectory handling
        if d:
            done_flag = True
            #x_logger.store(EpRet=ep_ret, EpLen=ep_len)
            logger.info('t: {}, ep_ret: {}, ep_len: {}'.format(
                t, ep_ret, ep_len))
            o, ep_ret, ep_len = env.reset(), 0, 0

        # Update handling
        if t >= update_after and t % update_every == 0:
            for j in range(update_every):
                update()

        if t % int(1e5) == 0:
            import gc
            gc.collect()

        # End of epoch handling
        if t % steps_per_epoch == 0:
            epoch = t // steps_per_epoch

            # Test the performance of the deterministic version of the agent.
            if epoch in {epochs}:
                val_ep_ret, val_ep_len = val_agent(100)
                logger.info('test score@epoch {}: {}, ep_len: {}'.format(
                    epoch, val_ep_ret, val_ep_len))

                ##if ep_ret > ep_ret_best:
                #if val_ep_ret > ep_ret_best:
                #    #ep_ret_best = ep_ret
                #    ep_ret_best = val_ep_ret
                #    torch.save(
                #        ac.state_dict(),
                #        os.path.join('output',
                #                     'model-{}.pth'.format(logger_args)))
                #if epoch in [10, 50, 100]:
                #    shutil.copy2(
                #        os.path.join('output',
                #                     'model-{}.pth'.format(logger_args)),
                #        os.path.join(
                #            'output',
                #            'model-{}-epoch_{}.pth'.format(logger_args,
                #                                           epoch)))

            if not done_flag:
                pass
                # default
                #x_logger.store(EpRet=0, EpLen=0)
            # reset
            done_flag = False
            ## Log info about epoch
            #x_logger.log_tabular('Epoch', epoch)
            #x_logger.log_tabular('EpRet', with_min_and_max=True)
            #x_logger.log_tabular('EpLen', average_only=True)
            #x_logger.log_tabular('TotalEnvInteracts', t)
            ##x_logger.log_tabular('Advs', with_min_and_max=True)
            ##x_logger.log_tabular('LossAdv', average_only=True)
            #x_logger.log_tabular('Time', time.time() - start_time)
            #x_logger.dump_tabular()


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, default='PongNoFrameskip-v4')
    parser.add_argument('--hid', type=int, default=256)
    parser.add_argument('--l', type=int, default=2)
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--seed', '-s', type=int, default=0)
    parser.add_argument('--epochs', type=int, default=50)
    args = parser.parse_args()

    print("env: {}, seed: {}, epochs: {}".format(args.env, args.seed,
                                                 args.epochs))

    #from spinup.utils.run_utils import setup_logger_kwargs
    #logger_kwargs = setup_logger_kwargs(args.exp_name, args.seed)
    #logger_args = '{}-s{}'.format(args.exp_name, args.seed)
    logger_kwargs, logger_args = None, None

    #torch.set_num_threads(torch.get_num_threads())
    torch.set_num_threads(int(num_threads))
    seed = args.seed
    torch.manual_seed(seed)
    random.seed(seed + 1)
    np.random.seed(seed + 2)

    x = lambda: make_env(args.env,
                         seed=args.seed + 3,
                         wrapper_kwargs={
                             'frame_stack': True,
                             'clip_rewards': False,
                             'episode_life': False,
                         })
    y = lambda: make_env(args.env,
                         seed=args.seed + 4,
                         wrapper_kwargs={
                             'frame_stack': True,
                             'clip_rewards': False,
                             'episode_life': False,
                         })
    sac(x,
        y,
        actor_critic=MLPActorCritic,
        ac_kwargs=dict(hidden_sizes=[args.hid] * args.l),
        gamma=args.gamma,
        seed=args.seed,
        epochs=args.epochs,
        logger_args=logger_args,
        logger_kwargs=logger_kwargs)
