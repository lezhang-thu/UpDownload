# input original data
base_path = 'dueling-sac-results'
env_names = [
    'Alien', 'Amidar', 'Assault', 'Asterix', 'BankHeist', 'BattleZone',
    'Boxing', 'Breakout', 'ChopperCommand', 'CrazyClimber', 'DemonAttack',
    'Freeway', 'Frostbite', 'Gopher', 'Hero', 'Jamesbond', 'Kangaroo', 'Krull',
    'KungFuMaster', 'MsPacman', 'Pong', 'PrivateEye', 'Qbert', 'RoadRunner',
    'Seaquest', 'UpNDown'
]
input_files = [[
    'normal-' + env_name + '-100K-results.txt' for env_name in env_names
]]
files = []

for ver_dir in input_files:
    ver_files = []
    for env_file in ver_dir:
        try:
            f = open(base_path + '/' + env_file, 'r')
        except IOError:
            print("Cannot open file:", env_file)
        ver_files.append(f)
    files.append(ver_files)

print("Read files for each version of alg. :", end=' ')
count = 0

for ver_files in files:
    count += len(ver_files)
    print(len(ver_files), sep=',', end='')
print('\nTotal:', count)

data = []
for file_ver in files:
    data_ver = []  # store data for each version
    for file in file_ver:  # iterate each env
        seed = None  # store seed name
        data_env = []  # store data for each env
        count = 0
        data_seed = []  # store data for each seed
        for idx, line in enumerate(file.readlines()):
            words = line.split()
            if words[0] == 'env:' and words[3] != seed:  # new seed
                if seed:
                    data_env.append(data_seed)
                seed = words[3]
                data_seed = []
            elif words[0] == '[INFO:':
                if words[3] == 't:':
                    # count += 1
                    # print('count:', count, 'ep_ret:', float(words[6][:-1]))
                    data_seed.append(float(words[6][:-1]))
                elif words[3] == 'test':
                    # count = 0
                    # print('test_score:', float(words[6][:-1]))
                    # data_seed.append(float(words[6][:-1]))
                    pass
        data_env.append(data_seed)
        data_ver.append(data_env)

        # check length of seeds manually
        # print("#seeds: ", len(data_env))
        # lens = 0
        # for data_seed in data_env:
        #     lens += len(data_seed)
        #     print(len(data_seed), end=' ')
        # print('total:', lens)
    data.append(data_ver)

# process data: padding each seed to the max length of all seeds of the same ver&env
import numpy as np


def pad_arrays(a):  # pad a list of lists of different lengths
    l = max((len(row) for row in a))
    aa = np.empty([len(a), l], dtype=float)
    for idx, row in enumerate(a):
        aa[idx] = np.pad(row, (0, l - len(row)),
                         'constant',
                         constant_values=np.nan)  # padding with np.nan
    return aa


data_pad = [[None for data_env in data_ver] for data_ver in data]
# print(len(data_pad), len(data_pad[0]))
for idx_ver, data_ver in enumerate(data):
    for idx_env, data_env in enumerate(data_ver):
        data_pad[idx_ver][idx_env] = pad_arrays(data_env)

data = data_pad  # #ver x #env lists, each element is a 2D ndarray containing seeds of the same length
print(len(data), len(data[0]), len(data[0][0]))

# draw
import matplotlib.pyplot as plt
import itertools

#import matplotlib
#matplotlib.rcParams.update({'font.size': 18})


# plot data as shadow areas
def plot_shadow(axs, x, data, params):
    # print([len(data_seed) for data_seed in data])
    # print(len(x), len(data[0]))
    # print(data[0][0], data[1][0], data[2][0])
    handle, = axs.plot(x,
                       np.nanmean(data, axis=0),
                       color=params['c1'],
                       linewidth=1.5)
    y1 = np.nanmin(data, axis=0)  # ignore any NaN values
    y2 = np.nanmax(data, axis=0)
    axs.fill_between(x, y1, y2, color=params['c2'])
    return handle


fig, axes = plt.subplots(7, 4)
axes = list(itertools.chain.from_iterable(axes))
fig.set_size_inches(24, 42)

colors = [
    ['#FF6E00FF', '#E7884233'],  # orange
    ['#008E0FFF', '#00FF0033'],  # green
    ['#FF66CCFF', '#FF99CC66'],  # red
    ['#9933FFFF', '#9933FF33'],  #purple
]  # for each version

handle_list = []
for idx_env, name_env in enumerate(env_names):
    for idx_ver, data_ver in enumerate(data):
        x = np.arange(0, len(data_ver[idx_env][0]), 1)
        handle = plot_shadow(axes[idx_env], x, data_ver[idx_env],
                             dict(c1=colors[idx_ver][0], c2=colors[idx_ver][1]))
        if name_env == 'Alien':
            handle_list.append(handle)

    axes[idx_env].set_title(name_env, fontsize='xx-large')
    # print(len(data_ver[idx_env][0]))
    # axes[idx_env].set_xlim([0, len(data_ver[idx_env][0])])

for idx in range(len(env_names), len(axes)):
    fig.delaxes(axes[idx])
# axes[0].legend(handles=handle_list,
#                labels=['vanilla', 'uniform', 'pure', 'dueling'],
#                loc='upper left',
#                fontsize='x-large')
axes[0].set_xlabel('#Episodes', fontsize='x-large')
axes[0].set_ylabel('Scores', fontsize='x-large')

fig.tight_layout()

fig.savefig('raw-scores.pdf')
