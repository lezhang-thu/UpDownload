base_path = 'comparison-results'
input_files = [
    [
        'Q-variant-version-1/Q-variant-Alien-100K-results.txt',
        'Q-variant-version-1/Q-variant-Gopher-100K-results.txt',
        'Q-variant-version-1/Q-variant-Hero-100K-results.txt',
        'Q-variant-version-1/Q-variant-KungFuMaster-100K-results.txt'
    ],
    [
        'uniform-replay-version-2/uniform-replay-Alien-100K-results.txt',
        'uniform-replay-version-2/uniform-replay-Gopher-100K-results.txt',
        'uniform-replay-version-2/uniform-replay-Hero-100K-results.txt',
        'uniform-replay-version-2/uniform-replay-KungFuMaster-100K-results.txt'
    ],
    [
        'pure-version-3/pure-Alien-100K-results.txt',
        'pure-version-3/pure-Gopher-100K-results.txt',
        'pure-version-3/pure-Hero-100K-results.txt',
        'pure-version-3/pure-KungFuMaster-100K-results.txt'
    ],
    [
        'normal-version-4/normal-Alien-100K-results.txt',
        'normal-version-4/normal-Gopher-100K-results.txt',
        'normal-version-4/normal-Hero-100K-results.txt',
        'normal-version-4/normal-KungFuMaster-100K-results.txt'
    ]
]
files = []
for ver_dir in input_files:
    ver_files = []
    for env_file in ver_dir:
        try:
            f = open(base_path + '/' + env_file, 'r')
        except IOError:
            print("Cannot open file:", env_file)
        ver_files.append(f)
    files.append(ver_files)

data = []
for file_ver in files:
    data_ver = []  # store data for each version
    for file in file_ver:  # iterate each env
        seed = None  # store seed name
        data_env = []  # store data for each env
        count = 0
        data_seed = []  # store data for each seed
        for idx, line in enumerate(file.readlines()):
            words = line.split()
            if words[0] == 'env:' and words[3] != seed:  # new seed
                if seed:
                    data_env.append(data_seed)
                seed = words[3]
                data_seed = []
            elif words[0] == '[INFO:':
                if words[3] == 't:':
                    # count += 1
                    # print('count:', count, 'ep_ret:', float(words[6][:-1]))
                    data_seed.append(float(words[6][:-1]))
                elif words[3] == 'test':
                    # count = 0
                    # print('test_score:', float(words[6][:-1]))
                    # data_seed.append(float(words[6][:-1]))
                    pass
        data_env.append(data_seed)
        data_ver.append(data_env)

        # check length of seeds manually
        # print("#seeds: ", len(data_env))
        # lens = 0
        # for data_seed in data_env:
        #     lens += len(data_seed)
        #     print(len(data_seed), end=' ')
        # print('total:', lens)
    data.append(data_ver)

# padding each seed to the max length of all seeds of the same ver&env
import numpy as np

# data = np.asarray(data)
data_pad = []
for data_ver in data:
    data_ver_pad = []
    for data_env in data_ver:
        l = 0
        for data_seed in data_env:
            l = max(l, len(data_seed))
            # print(len(data_seed))
        data_env_pad = []
        for data_seed in data_env:
            # data_seed_pad = np.pad(data_seed,l,'constant',constant_values=np.nan)
            data_seed_pad = np.concatenate(
                (data_seed, [np.nan] * (l - len(data_seed))), axis=None)
            # print("padding:", l, len(data_seed), len(data_seed_pad), data_seed[0],data_seed_pad[0])
            data_env_pad.append(data_seed_pad)
        data_ver_pad.append(data_env_pad)
    data_pad.append(data_ver_pad)
data = data_pad

import matplotlib.pyplot as plt

#import matplotlib
#matplotlib.rcParams.update({'font.size': 18})


# plot data as shadow areas
def plot_shadow(axs, x, data, params):
    # print([len(data_seed) for data_seed in data])
    # print(len(x), len(data[0]))
    # print(data[0][0], data[1][0], data[2][0])
    handle, = axs.plot(x,
                       np.nanmean(data, axis=0),
                       color=params['c1'],
                       linewidth=1.5)
    y1 = np.nanmin(data, axis=0)  # ignore any NaN values
    y2 = np.nanmax(data, axis=0)
    axs.fill_between(x, y1, y2, color=params['c2'])
    return handle


# draw
fig, axes = plt.subplots(1, 4)
fig.set_size_inches(24, 6)

env_names = ['Alien', 'Gopher', 'Hero', 'KungFuMaster']
colors = [['#FF66CCFF', '#FF99CC66'], ['#008E0FFF', '#00FF0033'],
          ['#9933FFFF', '#9933FF33'], ['#FF6E00FF', '#E7884233']]

handle_list = []
for idx_env, name_env in enumerate(env_names):
    for idx_ver, data_ver in enumerate(data):
        x = np.arange(0, len(data_ver[idx_env][0]), 1)
        handle = plot_shadow(axes[idx_env], x, data_ver[idx_env],
                             dict(c1=colors[idx_ver][0], c2=colors[idx_ver][1]))
        if name_env == 'Alien':
            handle_list.append(handle)

    axes[idx_env].set_title(name_env, fontsize='xx-large')
    # print(len(data_ver[idx_env][0]))
    # axes[idx_env].set_xlim([0, len(data_ver[idx_env][0])])

axes[0].legend(handles=handle_list,
               labels=['vanilla', 'uniform', 'pure', 'dueling'],
               loc='upper left',
               fontsize='x-large')
axes[0].set_xlabel('#Episodes', fontsize='x-large')
axes[0].set_ylabel('Scores', fontsize='x-large')

fig.tight_layout()
fig.savefig('exp-variants.pdf')
