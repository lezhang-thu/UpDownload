import os
import sys

num_threads = "4"
os.environ["OMP_NUM_THREADS"] = num_threads  # export OMP_NUM_THREADS=4
os.environ[
    "OPENBLAS_NUM_THREADS"] = num_threads  # export OPENBLAS_NUM_THREADS=4
os.environ["MKL_NUM_THREADS"] = num_threads  # export MKL_NUM_THREADS=6
os.environ[
    "VECLIB_MAXIMUM_THREADS"] = num_threads  # export VECLIB_MAXIMUM_THREADS=4
os.environ["NUMEXPR_NUM_THREADS"] = num_threads  # export NUMEXPR_NUM_THREADS=6
import time
import random
import typing
import logging
import shutil
from copy import deepcopy
import itertools
from collections import deque

import numpy as np
from scipy import stats

import torch
import torch.nn as nn
import torch.nn.functional as F
from core_critical import MLPActorCritic

from zeta_atari_env import make_env
from replay_buffer_critical import ReplayBuffer


def setup_logging(save_dir, logger_name):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)

    ch = logging.StreamHandler(stream=sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter("[%(levelname)s: %(asctime)s] %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    #if not os.path.exists(save_dir):
    #    os.makedirs(save_dir)

    #fh = logging.FileHandler(os.path.join(save_dir, '{}'.format(logger_name)))
    #fh.setLevel(logging.INFO)
    #fh.setFormatter(formatter)
    #logger.addHandler(fh)
    return logger


def sac(env_fn,
        val_env_fn,
        actor_critic=MLPActorCritic,
        seed=0,
        steps_per_epoch=int(1e4),
        epochs=100,
        replay_size=int(1e6),
        gamma=0.99,
        polyak=0.995,
        lr=1e-4,
        batch_size=100,
        start_steps=10000,
        update_after=1000,
        update_every=50,
        num_val_episodes=10):

    env = env_fn()
    val_env = val_env_fn()
    obs_dim = env.observation_space.shape
    act_dim = env.action_space.n
    print('act_dim: {}'.format(act_dim))

    # Create actor-critic module and target networks
    alpha = 1e-2
    ac = actor_critic(act_dim).cuda()
    ac_targ = deepcopy(ac)
    del ac_targ.conv
    # Freeze target networks with respect to optimizers (only update via polyak averaging)
    for x in ac_targ.parameters():
        x.requires_grad = False

    # Experience buffer
    replay_buffer = ReplayBuffer(replay_size)
    output_threshold = 1e-4

    def compute_pi_loss(data):
        o = ac.conv(data['obs'].cuda())
        _, logit_a = ac.pi(o)
        action_samples = torch.swapaxes(
            torch.distributions.categorical.Categorical(logits=logit_a).sample(
                (5,)), 0, 1)

        with torch.no_grad():
            q1 = ac.q1(o)
            q2 = ac.q2(o)
            y_q1 = torch.gather(q1, -1, action_samples)
            y_q2 = torch.gather(q2, -1, action_samples)
            mask = y_q1 > y_q2
            Q = mask * y_q2 + (~mask) * y_q1
            adv = Q - Q.mean(-1, True)

        logp_pi = F.log_softmax(logit_a, -1).gather(-1, action_samples)
        loss_pi = -(((adv - alpha * logp_pi).detach() * logp_pi).mean())
        return loss_pi

    def compute_offpolicy_loss(data):
        o = ac.conv(data['obs'])
        q1 = ac.q1(o)
        q2 = ac.q2(o)

        # Bellman backup for Q functions
        with torch.no_grad():
            # Target actions come from *current* policy
            o2 = ac.conv(data['obs2'])
            _, logit_a2 = ac.pi(o2)
            a2 = torch.distributions.categorical.Categorical(
                logits=logit_a2).sample().unsqueeze_(-1)

            targ_q1 = ac_targ.q1(o2)
            targ_q2 = ac_targ.q2(o2)
            targ_q1 = torch.gather(targ_q1, -1, a2).squeeze_(-1)
            targ_q2 = torch.gather(targ_q2, -1, a2).squeeze_(-1)
            targ_q = torch.min(targ_q1, targ_q2)

            r = torch.clip(data['rew'], -1, 1)
            backup = r + gamma * (1 - data['done']) * (-alpha * F.log_softmax(
                logit_a2, -1).gather(-1, a2).squeeze_(-1) + targ_q)

        a = data['act'].unsqueeze_(-1)
        x_q1 = torch.gather(q1, -1, a).squeeze_(-1)
        x_q2 = torch.gather(q2, -1, a).squeeze_(-1)
        return F.huber_loss(x_q1, backup) + F.huber_loss(x_q2, backup)

    full_opt = torch.optim.Adam(ac.parameters(), lr)

    def update():
        full_opt.zero_grad()
        compute_offpolicy_loss(replay_buffer.sample(batch_size)).backward()
        full_opt.step()

        full_opt.zero_grad()
        compute_pi_loss(replay_buffer.sample(batch_size, True)).backward()
        full_opt.step()

        # Finally, update target networks by polyak averaging.
        with torch.no_grad():
            for x, x_targ in zip([ac.q1, ac.q2, ac.pi],
                                 [ac_targ.q1, ac_targ.q2, ac_targ.pi]):
                for p, p_targ in zip(x.parameters(), x_targ.parameters()):
                    # NB: We use an in-place operations "mul_", "add_" to update target
                    # params, as opposed to "mul" and "add", which would make new tensors.
                    p_targ.data.mul_(polyak)
                    p_targ.data.add_((1 - polyak) * p.data)

    @torch.no_grad()
    def get_action(o):
        o = torch.from_numpy(np.asarray(o, dtype=np.float32)).unsqueeze(0)
        return ac.act(o.cuda())

    def val_agent(m):
        ep_ret, ep_len = 0, 0
        for j in range(m):
            o, d = val_env.reset(), False
            while not d:
                # Take deterministic actions at test time
                o, r, d, _ = val_env.step(get_action(o))
                ep_ret += r
                ep_len += 1
        return ep_ret / m, ep_len / m

    logger = setup_logging('output', '{}.txt'.format('None'))
    # Prepare for interaction with environment
    total_steps = steps_per_epoch * epochs
    o, ep_ret, ep_len = env.reset(), 0, 0
    ep_ret_best = -1e5
    # Main loop: collect experience in env and update/log each epoch
    for t in range(1, total_steps + 1):
        if t > start_steps:
            a = get_action(o)
        else:
            a = env.action_space.sample()

        # Step the env
        o2, r, d, _ = env.step(a)

        ep_ret += r
        ep_len += 1

        # Store experience to replay buffer
        replay_buffer.add(o, a, r, o2, float(d))

        # Super critical, easy to overlook step: make sure to update
        # most recent observation!
        o = o2

        # End of trajectory handling
        if d:
            logger.info('t: {}, ep_ret: {}, ep_len: {}'.format(
                t, ep_ret, ep_len))

            o, ep_ret, ep_len = env.reset(), 0, 0

        # Update handling
        if t >= update_after and t % update_every == 0:
            for j in range(update_every):
                update()

        if t % int(1e5) == 0:
            import gc
            gc.collect()

        # End of epoch handling
        if t % steps_per_epoch == 0:
            epoch = t // steps_per_epoch

            # Test the performance of the deterministic version of the agent.
            if epoch in {1, 10, epochs}:
                val_ep_ret, val_ep_len = val_agent(100)
                logger.info('test score@epoch {}: {}, ep_len: {}'.format(
                    epoch, val_ep_ret, val_ep_len))

                ##if ep_ret > ep_ret_best:
                #if val_ep_ret > ep_ret_best:
                #    #ep_ret_best = ep_ret
                #    ep_ret_best = val_ep_ret
                #    torch.save(
                #        ac.state_dict(),
                #        os.path.join('output',
                #                     'model-{}.pth'.format(logger_args)))
                #if epoch in [10, 50, 100]:
                #    shutil.copy2(
                #        os.path.join('output',
                #                     'model-{}.pth'.format(logger_args)),
                #        os.path.join(
                #            'output',
                #            'model-{}-epoch_{}.pth'.format(logger_args,
                #                                           epoch)))


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, default='PongNoFrameskip-v4')
    parser.add_argument('--hid', type=int, default=256)
    parser.add_argument('--l', type=int, default=2)
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--seed', '-s', type=int, default=0)
    parser.add_argument('--epochs', type=int, default=50)
    args = parser.parse_args()

    print("env: {}, seed: {}, epochs: {}".format(args.env, args.seed,
                                                 args.epochs))

    torch.set_num_threads(int(num_threads))
    seed = args.seed
    torch.manual_seed(seed)
    random.seed(seed + 1)
    np.random.seed(seed + 2)

    x = lambda: make_env(args.env,
                         seed=args.seed + 3,
                         wrapper_kwargs={
                             'frame_stack': True,
                             'clip_rewards': False,
                             'episode_life': False,
                         })
    y = lambda: make_env(args.env,
                         seed=args.seed + 4,
                         wrapper_kwargs={
                             'frame_stack': True,
                             'clip_rewards': False,
                             'episode_life': False,
                         })
    sac(x,
        y,
        actor_critic=MLPActorCritic,
        gamma=args.gamma,
        seed=args.seed,
        epochs=args.epochs)
