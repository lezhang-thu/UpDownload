import numpy as np
import random

import torch
import torch.nn.functional as F

from segment_tree import SumSegmentTree, MinSegmentTree


class ReplayBuffer(object):

    def __init__(self,
                 size,
                 multistep=1,
                 gamma=0.99,
                 tau=0.01,
                 ac=None,
                 ac_targ=None,
                 batch_size=32):
        """Create Replay buffer.

        Parameters
        ----------
        size: int
            Max number of transitions to store in the buffer. When the buffer
            overflows the old memories are dropped.
        """
        self._storage = []
        self._maxsize = size
        self._next_idx = 0
        self._multistep = multistep
        self._gamma = gamma
        self._tau = tau
        self._ac = ac
        self._ac_targ = ac_targ
        self._batch_size = batch_size

        # self._coef: \gamma^1, ..., \gamma^n
        with torch.no_grad():
            self._coef = self._gamma * torch.pow(
                self._gamma, torch.arange(self._multistep)).cuda()

    def __len__(self):
        return len(self._storage)

    def add(self, obs_t, action, reward, obs_tp1, done, self_info):
        data = (obs_t, action, reward, obs_tp1, done)

        if self._next_idx >= len(self._storage):
            self._storage.append(data)
        else:
            self._storage[self._next_idx] = data
        self._next_idx = (self._next_idx + 1) % self._maxsize

    @torch.no_grad()
    def _encode_sample(self, idxes):
        obses_t, actions, rewards, obses_tp1, dones = [], [], [], [], []
        forward_obs = []
        forward_act = []
        forward_rew = []
        mask = []
        for i in idxes:
            data = self._storage[i]
            obs_t, action, reward, obs_tp1, done = data

            # multistep - start
            flag = False if done == 1.0 else True
            end_idx = i
            for k in range(self._multistep - 1):
                # TODO No wrap mechanism implemented
                if flag and end_idx + 1 < len(self._storage):
                    end_idx += 1
                    z = self._storage[end_idx]
                    forward_obs.append(z[0])
                    forward_act.append(z[1])
                    forward_rew.append(z[2])
                    mask.append(True)
                    if z[4] == 1.0:
                        flag = False
                else:
                    forward_obs.append(np.zeros_like(obs_t))
                    forward_act.append(0)
                    forward_rew.append(0.0)
                    mask.append(False)
            # multistep - end

            # bootstrap
            obs_tp1 = self._storage[end_idx][3]
            done = self._storage[end_idx][4]

            obses_t.append(obs_t)
            actions.append(action)
            rewards.append(reward)
            obses_tp1.append(obs_tp1)
            dones.append(done)

        x_obs = forward_obs
        if self._multistep > 1:
            # init & cuda()
            forward_obs = torch.from_numpy(np.asarray(x_obs)).cuda()
            mask = torch.from_numpy(np.asarray(mask)).cuda()
            forward_act = torch.from_numpy(
                np.asarray(forward_act)).unsqueeze(-1).cuda()
            forward_rew = torch.from_numpy(np.asarray(forward_rew)).cuda()

            forward_conv = self._ac.conv(forward_obs)
            logit = self._ac.pi(forward_conv)[1]
            targ_q_values = self._ac_targ.Q_values(
                forward_conv, None, True,
                self._ac_targ.pi(forward_conv)[1])
            log_prob = F.log_softmax(logit, -1)
            prob = F.softmax(logit, -1)

            prob_specific = prob.gather(-1, forward_act).squeeze(-1)
            targ_q_specific = targ_q_values.gather(-1, forward_act).squeeze(-1)

            reward_term = (prob * (-self._tau * log_prob + targ_q_values)).sum(
                -1
            ) - prob_specific * targ_q_specific + prob_specific * torch.clip(
                forward_rew, -1, 1)
            reward_term *= mask

            coef_return = prob_specific.reshape(self._batch_size,
                                                self._multistep - 1)
            coef_return = torch.cumprod(coef_return, -1)
            coef_return = torch.cat([
                torch.ones((self._batch_size, 1), dtype=torch.float32).cuda(),
                coef_return
            ], -1)
            coef_return *= self._coef
            offpolicy_rew = (
                reward_term.reshape(self._batch_size, self._multistep - 1) *
                coef_return[:, :-1]).sum(-1)
            coef_return = coef_return.gather(-1, (mask.reshape(
                self._batch_size,
                self._multistep - 1).sum(-1)).unsqueeze(-1)).squeeze(-1)

            rewards = np.clip(np.asarray(rewards), -1,
                              1) + offpolicy_rew.detach().cpu().numpy()
            valid_len = coef_return
        else:
            rewards = np.clip(np.asarray(rewards), -1, 1)
            valid_len = torch.full((self._batch_size,), self._gamma).cuda()

        # debug
        del x_obs[:]
        batch = dict(obs=np.asarray(obses_t),
                     obs2=np.asarray(obses_tp1),
                     rew=np.asarray(rewards),
                     done=np.asarray(dones))
        x = {
            k: torch.as_tensor(v, dtype=torch.float32).cuda()
            for k, v in batch.items()
        }
        x['act'] = torch.as_tensor(np.asarray(actions), dtype=torch.int64)
        x['valid'] = valid_len
        del obses_t[:]
        del obses_tp1[:]
        del batch
        return x

    def sample(self, batch_size):
        """Sample a batch of experiences.

        Parameters
        ----------
        batch_size: int
            How many transitions to sample.

        Returns
        -------
        obs_batch: np.array
            batch of observations
        act_batch: np.array
            batch of actions executed given obs_batch
        rew_batch: np.array
            rewards received as results of executing act_batch
        next_obs_batch: np.array
            next set of observations seen after executing act_batch
        done_mask: np.array
            done_mask[i] = 1 if executing act_batch[i] resulted in
            the end of an episode and 0 otherwise.
        """
        idxes = [
            random.randint(0,
                           len(self._storage) - 1) for _ in range(batch_size)
        ]
        return self._encode_sample(idxes)


class PrioritizedReplayBuffer(ReplayBuffer):

    def __init__(self, size, alpha, multistep, tau, ac, ac_targ, batch_size):
        """Create Prioritized Replay buffer.

        Parameters
        ----------
        size: int
            Max number of transitions to store in the buffer. When the buffer
            overflows the old memories are dropped.
        alpha: float
            how much prioritization is used
            (0 - no prioritization, 1 - full prioritization)

        See Also
        --------
        ReplayBuffer.__init__
        """
        super(PrioritizedReplayBuffer, self).__init__(size,
                                                      multistep=multistep,
                                                      tau=tau,
                                                      ac=ac,
                                                      ac_targ=ac_targ,
                                                      batch_size=batch_size)
        assert alpha >= 0
        self._alpha = alpha

        it_capacity = 1
        while it_capacity < size:
            it_capacity *= 2

        self._it_sum = SumSegmentTree(it_capacity)
        self._it_min = MinSegmentTree(it_capacity)
        self._max_priority = 1.0

    def add(self, *args, **kwargs):
        """See ReplayBuffer.store_effect"""
        idx = self._next_idx
        super().add(*args, **kwargs)
        self._it_sum[idx] = self._max_priority**self._alpha
        self._it_min[idx] = self._max_priority**self._alpha

    def _sample_proportional(self, batch_size):
        res = []
        p_total = self._it_sum.sum(0, len(self._storage) - 1)
        every_range_len = p_total / batch_size
        for i in range(batch_size):
            mass = random.random() * every_range_len + i * every_range_len
            idx = self._it_sum.find_prefixsum_idx(mass)
            res.append(idx)
        return res

    def sample(self, batch_size, beta):
        """Sample a batch of experiences.

        compared to ReplayBuffer.sample
        it also returns importance weights and idxes
        of sampled experiences.


        Parameters
        ----------
        batch_size: int
            How many transitions to sample.
        beta: float
            To what degree to use importance weights
            (0 - no corrections, 1 - full correction)

        Returns
        -------
        obs_batch: np.array
            batch of observations
        act_batch: np.array
            batch of actions executed given obs_batch
        rew_batch: np.array
            rewards received as results of executing act_batch
        next_obs_batch: np.array
            next set of observations seen after executing act_batch
        done_mask: np.array
            done_mask[i] = 1 if executing act_batch[i] resulted in
            the end of an episode and 0 otherwise.
        weights: np.array
            Array of shape (batch_size,) and dtype np.float32
            denoting importance weight of each sampled transition
        idxes: np.array
            Array of shape (batch_size,) and dtype np.int32
            idexes in buffer of sampled experiences
        """
        assert beta > 0

        idxes = self._sample_proportional(batch_size)

        weights = []
        p_min = self._it_min.min() / self._it_sum.sum()
        max_weight = (p_min * len(self._storage))**(-beta)

        for idx in idxes:
            p_sample = self._it_sum[idx] / self._it_sum.sum()
            weight = (p_sample * len(self._storage))**(-beta)
            weights.append(weight / max_weight)
        weights = np.array(weights)
        encoded_sample = self._encode_sample(idxes)
        #return tuple(list(encoded_sample) + [weights, idxes])
        return (encoded_sample, weights, idxes)

    def update_priorities(self, idxes, priorities):
        """Update priorities of sampled transitions.

        sets priority of transition at index idxes[i] in buffer
        to priorities[i].

        Parameters
        ----------
        idxes: [int]
            List of idxes of sampled transitions
        priorities: [float]
            List of updated priorities corresponding to
            transitions at the sampled idxes denoted by
            variable `idxes`.
        """
        assert len(idxes) == len(priorities)
        for idx, priority in zip(idxes, priorities):
            assert priority > 0
            assert 0 <= idx < len(self._storage)
            self._it_sum[idx] = priority**self._alpha
            self._it_min[idx] = priority**self._alpha

            self._max_priority = max(self._max_priority, priority)
