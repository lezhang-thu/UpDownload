import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


class MLPActor(nn.Module):

    def __init__(self, obs_dim, num_actions, hidden_sizes, activation):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(3136, 512), nn.ReLU(),
                                 nn.Linear(512, num_actions))

    def forward(self, obs, deterministic=False, with_logprob=True):
        logit = self.net(obs)
        if deterministic:
            actions = logit.argmax(1)
        else:
            actions = torch.distributions.categorical.Categorical(
                logits=logit).sample()

        return actions, logit, None


class MLPActorCritic(nn.Module):

    def __init__(self,
                 obs_dim,
                 act_dim,
                 hidden_sizes=(256, 256),
                 activation=nn.ReLU,
                 alpha=1e-2):
        super().__init__()

        self.conv = ConvOnly(4, obs_dim)
        # build policy and value functions
        self.pi = MLPActor(obs_dim, act_dim, hidden_sizes, activation)
        self.v1 = nn.Sequential(nn.Linear(3136, 512), nn.ReLU(),
                                nn.Linear(512, 1))
        self.adv1 = nn.Sequential(nn.Linear(3136, 512), nn.ReLU(),
                                  nn.Linear(512, act_dim))
        self._alpha = alpha

    def Q_values(self, obs, action=None, conv_feature=False, logit=None):
        if not conv_feature:
            obs = self.conv(obs)
        v = self.v1(obs)
        adv = self.adv1(obs)
        x = torch.distributions.categorical.Categorical(logits=logit)

        #q1 = v1 + (adv1 - adv1.mean(-1, keepdim=True))
        q = v + adv - (adv * F.softmax(logit, -1).detach()).sum(
            -1, True) - self._alpha * x.entropy().unsqueeze(-1).detach()
        if action is not None:
            q = torch.gather(q, -1, action.unsqueeze(-1)).squeeze(-1)
        return q

    def Adv_values(self, obs, action, logit=None):
        adv = self.adv1(obs)
        x = torch.distributions.categorical.Categorical(logits=logit)
        baseline = (adv * F.softmax(logit, -1).detach()).sum(
            -1, True) + self._alpha * x.entropy().unsqueeze(-1).detach()
        adv = adv - baseline
        v = self.v1(obs)
        return adv, F.huber_loss(v, baseline,
                                 reduction='none'), (v - baseline).squeeze_(-1)

    def act(self, obs, deterministic=False):
        with torch.no_grad():
            obs = self.conv(obs)
            a, logit, _ = self.pi(obs, deterministic, False)
            self_info = -F.log_softmax(logit, -1).gather(
                -1, a.unsqueeze(-1)).squeeze(-1)
            return a.squeeze(
                0).detach().cpu().numpy(), self_info.detach().cpu().numpy()


class ConvOnly(nn.Module):

    def __init__(self, frame_stack, obs_dim):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(frame_stack, 32, kernel_size=8, stride=4, padding=0),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=0),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),
            nn.ReLU(),
            nn.Flatten(),
        )

        #self.cnn = nn.Sequential(
        #        nn.Conv2d(frame_stack, 32, 5, stride=5, padding=0),
        #        nn.ReLU(),
        #        nn.Conv2d(32, 64, 5, stride=5, padding=0),
        #        nn.ReLU(),
        #        nn.Flatten())

    def forward(self, obs):
        obs = obs.to(torch.float32) / 255.0
        # (B, C, H, W)
        obs = obs.permute(0, 3, 1, 2)
        return self.cnn(obs)
