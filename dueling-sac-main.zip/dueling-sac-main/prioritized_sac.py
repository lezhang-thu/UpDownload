import sys
import os

num_threads = "4"
os.environ["OMP_NUM_THREADS"] = num_threads  # export OMP_NUM_THREADS=4
os.environ[
    "OPENBLAS_NUM_THREADS"] = num_threads  # export OPENBLAS_NUM_THREADS=4
os.environ["MKL_NUM_THREADS"] = num_threads  # export MKL_NUM_THREADS=6
os.environ[
    "VECLIB_MAXIMUM_THREADS"] = num_threads  # export VECLIB_MAXIMUM_THREADS=4
os.environ["NUMEXPR_NUM_THREADS"] = num_threads  # export NUMEXPR_NUM_THREADS=6

import gc
import time
import random
import logging
import shutil
from copy import deepcopy
import itertools
import numpy as np
import torch
import torch.nn.functional as F
import trial_core as core

from zeta_atari_env import make_env
from offpolicy_replay_buffer import PrioritizedReplayBuffer


class LinearSchedule(object):

    def __init__(self, schedule_timesteps, final_p, initial_p=1.0):
        """Linear interpolation between initial_p and final_p over
        schedule_timesteps. After this many timesteps pass final_p is
        returned.
        Parameters
        ----------
        schedule_timesteps: int
            Number of timesteps for which to linearly anneal initial_p
            to final_p
        initial_p: float
            initial output value
        final_p: float
            final output value
        """
        self.schedule_timesteps = schedule_timesteps
        self.final_p = final_p
        self.initial_p = initial_p

    def value(self, t):
        """See Schedule.value"""
        fraction = min(float(t) / self.schedule_timesteps, 1.0)
        return self.initial_p + fraction * (self.final_p - self.initial_p)


def setup_logging(save_dir, logger_name):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)

    ch = logging.StreamHandler(stream=sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter("[%(levelname)s: %(asctime)s] %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    #if not os.path.exists(save_dir):
    #    os.makedirs(save_dir)

    #fh = logging.FileHandler(os.path.join(save_dir, '{}'.format(logger_name)))
    #fh.setLevel(logging.INFO)
    #fh.setFormatter(formatter)
    #logger.addHandler(fh)
    return logger


def sac(
        env_fn,
        val_env_fn,
        actor_critic=core.MLPActorCritic,
        ac_kwargs=dict(),
        seed=0,
        steps_per_epoch=int(1e4),
        #epochs=100,
        epochs=100,
        replay_size=int(0.5e6),
        #replay_size=int(1e5),
        gamma=0.99,
        polyak=0.995,
        #polyak=0.5,
        lr=1e-4,
        #lr=1e-3,
        batch_size=100,
        start_steps=int(1e4),
        update_after=int(1e3),
        #update_after=1600,
        update_every=50,
        num_val_episodes=10):

    env = env_fn()
    val_env = val_env_fn()
    obs_dim = env.observation_space.shape
    act_dim = env.action_space.n
    print('act_dim: {}'.format(act_dim))

    # Create actor-critic module and target networks
    alpha = 1e-2
    ac_kwargs['alpha'] = alpha
    ac = actor_critic(376, act_dim, **ac_kwargs).cuda()
    ac_targ = deepcopy(ac)
    del ac_targ.conv
    # Freeze target networks with respect to optimizers (only update via polyak averaging)
    for x in ac_targ.parameters():
        x.requires_grad = False

    total_steps = steps_per_epoch * epochs
    prioritized_replay_alpha = 0.5
    prioritized_replay_beta0 = 0.4
    prioritized_replay_beta_iters = total_steps
    prioritized_replay_eps = 1e-6
    # Experience buffer
    replay_buffer = PrioritizedReplayBuffer(replay_size,
                                            alpha=prioritized_replay_alpha,
                                            multistep=1,
                                            tau=alpha,
                                            ac=ac,
                                            ac_targ=ac_targ,
                                            batch_size=batch_size)
    beta_schedule = LinearSchedule(prioritized_replay_beta_iters,
                                   initial_p=prioritized_replay_beta0,
                                   final_p=1.0)

    #output_threshold = 1e-4

    def compute_loss(data, weights):
        o, a, r, o2, d, valid_len = data['obs'], data['act'], data['rew'], data[
            'obs2'], data['done'], data['valid']
        r = torch.clip(r.cuda(), -1, 1)
        #r = r.cuda()
        d = d.cuda()
        o = ac.conv(o.cuda())
        a = a.cuda()
        logit_a = ac.pi(o)[1]

        adv4a_pi, v_loss, v_errors = ac.Adv_values(o, None, logit_a)
        prob = F.softmax(logit_a, -1)

        a_entropy = torch.distributions.categorical.Categorical(
            logits=logit_a).entropy()
        with torch.no_grad():
            kl_replay = F.log_softmax(adv4a_pi.detach() / alpha, -1)
            kl_div = F.kl_div(kl_replay, prob, reduction='none').sum(-1)
            pi_errors = kl_div.detach().cpu().numpy() * alpha
        loss_pi = -alpha * a_entropy - (adv4a_pi.detach() * prob).sum(-1)

        q = ac.Q_values(o, a, True, logit_a)
        # Bellman backup for Q functions
        with torch.no_grad():
            # Target actions come from *current* policy
            o2 = ac.conv(o2.cuda())
            _, logit_a2, _ = ac.pi(o2)
            targ_q_values = ac_targ.Q_values(o2, None, True, ac_targ.pi(o2)[1])
            log_prob = F.log_softmax(logit_a2, -1)
            prob = F.softmax(logit_a2, -1)

            coef = valid_len
            backup = r + coef * (1 - d) * (
                prob * (-alpha * log_prob + targ_q_values)).sum(-1)

            ## Target actions come from *current* policy
            #o2 = ac.conv(o2.cuda())
            #a2, logit_a2, _ = ac.pi(o2)
            #targ_q_values = ac_targ.Q_values(o2, None, True, ac_targ.pi(o2)[1])
            #a2 = a2.unsqueeze(-1)

            #coef = valid_len
            #backup = r + coef * (1 - d) * (
            #    -alpha * F.log_softmax(logit_a2, -1).gather(-1, a2) +
            #    targ_q_values.gather(-1, a2)).squeeze(-1)
        #
        x = F.huber_loss(q, backup, reduction='none')
        v_loss.squeeze_(-1)
        td_errors = np.abs((q - backup).detach().cpu().numpy()) + np.abs(
            v_errors.detach().cpu().numpy()) + np.abs(pi_errors)
        #with torch.no_grad():
        #    if random.uniform(0, 1) < output_threshold:
        #        print('*' * 23)
        #        print(r)
        #        print('softmax[:2]: {}'.format(prob[:2]))
        #        print('a_entropy:', a_entropy.mean())
        #        print('pi_errors[:10]: {}'.format(pi_errors[:10]))
        #        print('td_q_errors[:10]: {}'.format((q - backup).detach().cpu().numpy()[:10]))
        #        print('td_v_errors[:10]: {}'.format(v_errors.detach().cpu().numpy()[:10]))
        return ((loss_pi + x + v_loss) * weights).mean(), td_errors

    full_opt = torch.optim.Adam(ac.parameters(), lr)

    def update(t):
        data, weights, batch_idxes = replay_buffer.sample(
            batch_size, beta=beta_schedule.value(t))
        full_opt.zero_grad()
        loss, td_errors = compute_loss(data, torch.from_numpy(weights).cuda())
        new_priorities = td_errors + prioritized_replay_eps
        replay_buffer.update_priorities(batch_idxes, new_priorities)
        loss.backward()
        full_opt.step()

        # debug
        del data
        del td_errors
        del loss

        #if t % int(2e3) == 0:
        #   ac_targ.load_state_dict(ac.state_dict(), strict=False)
        # Finally, update target networks by polyak averaging.
        with torch.no_grad():
            for x, x_targ in zip([ac.v1, ac.adv1, ac.pi],
                                 [ac_targ.v1, ac_targ.adv1, ac_targ.pi]):
                for p, p_targ in zip(x.parameters(), x_targ.parameters()):
                    # NB: We use an in-place operations "mul_", "add_" to update target
                    # params, as opposed to "mul" and "add", which would make new tensors.
                    p_targ.data.mul_(polyak)
                    p_targ.data.add_((1 - polyak) * p.data)

    @torch.no_grad()
    def get_action(o, deterministic=False):
        o = torch.from_numpy(np.asarray(o)).unsqueeze(0).cuda()
        return ac.act(torch.as_tensor(o, dtype=torch.float32), deterministic)

    def val_agent(m):
        ep_ret, ep_len = 0, 0
        for j in range(m):
            o, d = val_env.reset(), False
            while not d:
                # Take deterministic actions at test time
                o, r, d, _ = val_env.step(get_action(o, True)[0])
                ep_ret += r
                ep_len += 1
        return ep_ret / m, ep_len / m

    logger = setup_logging('output', '{}.txt'.format('None'))
    # Prepare for interaction with environment
    start_time = time.time()
    o, ep_ret, ep_len = env.reset(), 0, 0
    ep_ret_best = -1e5
    done_flag = False
    # Main loop: collect experience in env and update/log each epoch
    for t in range(1, total_steps + 1):
        if t > start_steps:
            a, _ = get_action(o)
        else:
            a = env.action_space.sample()
        #a, self_info = get_action(o)
        # Step the env
        o2, r, d, _ = env.step(a)

        ep_ret += r
        ep_len += 1

        #assert -1 <= r <= 1
        # Store experience to replay buffer
        replay_buffer.add(o, a, r, o2, float(d), 1.0)  #float(self_info))

        # Super critical, easy to overlook step: make sure to update
        # most recent observation!
        o = o2

        # End of trajectory handling
        if d:
            done_flag = True
            logger.info('t: {}, ep_ret: {}, ep_len: {}'.format(
                t, ep_ret, ep_len))
            o, ep_ret, ep_len = env.reset(), 0, 0

        # Update handling
        if t >= update_after and t % update_every == 0:
            for j in range(update_every):
                update(t)
        #if t >= update_after:
        #    update(t)

        if t % int(1e5) == 0:
            gc.collect()

        # End of epoch handling
        if t % steps_per_epoch == 0:
            epoch = t // steps_per_epoch

            # Test the performance of the deterministic version of the agent.
            if epoch in {epochs}:
                val_ep_ret, val_ep_len = val_agent(
                    100)  #val_agent(num_val_episodes)
                logger.info('test score@epoch {}: {}, ep_len: {}'.format(
                    epoch, val_ep_ret, val_ep_len))

                #if ep_ret > ep_ret_best:
                #if val_ep_ret > ep_ret_best:
                #    #ep_ret_best = ep_ret
                #    ep_ret_best = val_ep_ret
                #    torch.save(
                #        ac.state_dict(),
                #        os.path.join('output',
                #                     'model-{}.pth'.format(logger_args)))
                #if epoch in [10, 50, 100]:
                #    shutil.copy2(
                #        os.path.join('output',
                #                     'model-{}.pth'.format(logger_args)),
                #        os.path.join(
                #            'output',
                #            'model-{}-epoch_{}.pth'.format(logger_args,
                #                                           epoch)))

            if not done_flag:
                pass
                # default
            # reset
            done_flag = False


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, default='PongNoFrameskip-v4')
    parser.add_argument('--hid', type=int, default=256)
    parser.add_argument('--l', type=int, default=2)
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--seed', '-s', type=int, default=0)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--exp_name', type=str, default='sac')
    args = parser.parse_args()

    print("env: {}, seed: {}, epochs: {}".format(args.env, args.seed,
                                                 args.epochs))

    torch.set_num_threads(int(num_threads))
    seed = args.seed
    torch.manual_seed(seed)
    random.seed(seed + 1)
    np.random.seed(seed + 2)

    x = lambda: make_env(args.env,
                         seed=args.seed + 3,
                         wrapper_kwargs={
                             'frame_stack': True,
                             'clip_rewards': False,
                             'episode_life': False,
                         })
    y = lambda: make_env(args.env,
                         seed=args.seed + 4,
                         wrapper_kwargs={
                             'frame_stack': True,
                             'clip_rewards': False,
                             'episode_life': False,
                         })
    sac(x,
        y,
        actor_critic=core.MLPActorCritic,
        ac_kwargs=dict(hidden_sizes=[args.hid] * args.l),
        gamma=args.gamma,
        seed=args.seed,
        epochs=args.epochs)
